# app.py

from flask import Flask, render_template, request, redirect, session, url_for, jsonify
from models import db, User, FamilyMember, Alarm
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from face_detector import recognize_faces_in_image
from face_detector import train_face_data
import os
import json
import glob
import cv2



app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

UPLOAD_FOLDER = 'static/uploads'
SLIDESHOW_FOLDER = os.path.join(UPLOAD_FOLDER, 'slideshow_uploads')
os.makedirs(SLIDESHOW_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SLIDESHOW_FOLDER'] = SLIDESHOW_FOLDER
db.init_app(app)

@app.route('/')
def home():
    return redirect('/login')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        userid = request.form['userid']
        name = request.form['name']
        password = request.form['password']

        existing_user = User.query.filter_by(userid=userid).first()
        if existing_user:
            return render_template('signup.html', error="이미 존재하는 아이디입니다.")

        hashed_pw = generate_password_hash(password)
        new_user = User(userid=userid, name=name, password=hashed_pw)
        db.session.add(new_user)
        db.session.commit()
        return redirect('/login')
    
    return render_template('signup.html')

@app.route('/check_userid')
def check_userid():
    userid = request.args.get('userid')
    exists = User.query.filter_by(userid=userid).first() is not None
    return jsonify({'exists': exists})
    
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userid = request.form['userid']
        pw = request.form['password']
        user = User.query.filter_by(userid=userid).first()
        if user and check_password_hash(user.password, pw):
            session['user'] = user.userid
            return redirect('/main')
        return render_template('login.html', error="아이디 또는 비밀번호가 일치하지 않습니다.")
    return render_template('login.html')

@app.route('/main', methods=['GET', 'POST'])
def dashboard():
    if 'user' not in session:
        return redirect('/login')

    if request.method == 'POST':
        image = request.files.get('image')
        if image and image.filename:
            userid = session['user']
            album_folder = os.path.join(app.config['UPLOAD_FOLDER'], userid, 'album')
            os.makedirs(album_folder, exist_ok=True)

            # 📌 저장될 다음 인덱스 구하기
            existing_files = glob.glob(os.path.join(album_folder, '*.jpg'))
            next_index = len(existing_files) + 1
            filename = f"{next_index}.jpg"
            image_path = os.path.join(album_folder, filename)

            # 📌 메모리 상에서 얼굴 인식 후 결과 이미지만 저장
            image.save('temp.jpg')  # 임시 저장
            result_image = recognize_faces_in_image('temp.jpg')  # 얼굴 인식
            os.remove('temp.jpg')  # 임시 파일 삭제

            cv2.imwrite(image_path, result_image)

            relative_path = f"{userid}/album/{filename}"
            return redirect(url_for('show_uploaded_image', filename=relative_path))

    return render_template('main_page.html')


@app.route('/uploaded/<path:filename>')
def show_uploaded_image(filename):
    return render_template('show_image.html', filename=filename)

@app.route('/upload_profile_image', methods=['POST'])
def upload_profile_image():
    if 'user' not in session:
        return redirect('/login')

    file = request.files.get('profile_img')
    if file and file.filename:
        user_folder = os.path.join(app.config['UPLOAD_FOLDER'], session['user'])
        os.makedirs(user_folder, exist_ok=True)
        filepath = os.path.join(user_folder, 'profile.jpg')  # 항상 profile.jpg로 저장
        file.save(filepath)
    return redirect('/profile')
    
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect('/login')

    userid = session['user']
    user = User.query.filter_by(userid=userid).first()
    if not user:
        return "해당 유저를 찾을 수 없습니다.", 404

    # ✅ 프로필 사진 업로드 처리
    if request.method == 'POST':
        image = request.files.get('profile_img')  # <-- 여기 name="profile_img"로 수정됨
        if image and image.filename:
            user_folder = os.path.join(app.config['UPLOAD_FOLDER'], userid)
            os.makedirs(user_folder, exist_ok=True)
            save_path = os.path.join(user_folder, "profile.jpg")
            image.save(save_path)

    return render_template('profile.html', user=user)



@app.route('/edit_family', methods=['GET', 'POST'])
def edit_family():
    if 'user' not in session:
        return redirect('/login')

    user = User.query.filter_by(userid=session['user']).first()

    if request.method == 'POST':
        for key in request.form:
            if key.endswith('_name'):
                member_id = key.split('_')[1]
                name = request.form.get(f'member_{member_id}_name')
                relation = request.form.get(f'member_{member_id}_relation')
                traits = request.form.get(f'member_{member_id}_traits')
                images = request.files.getlist(f'member_{member_id}_images')

                # ❗️사진 개수 검증
                if len(images) != 10:
                    family_members = FamilyMember.query.filter_by(user_id=user.id).all()
                    return render_template("edit_family.html", family_members=family_members,
                                           error="각 구성원은 정확히 10장의 사진을 업로드해야 합니다.")

                # 🧩 업로드 경로 생성: static/uploads/<user_id>/<member_name>/
                base_folder = os.path.join(app.config['UPLOAD_FOLDER'], session['user'], name)
                os.makedirs(base_folder, exist_ok=True)

                saved_filenames = []
                for image in images:
                    if image and image.filename:
                        ext = os.path.splitext(image.filename)[1].lower()  # 예: .jpg, .png
                        if ext not in ['.jpg', '.jpeg', '.png']:
                            continue  # 허용된 확장자만 저장

                        existing_files = glob.glob(os.path.join(base_folder, "*"))
                        next_index = len(existing_files) + 1
                        filename = f"{next_index}{ext}"
                        image.save(os.path.join(base_folder, filename))
                        saved_filenames.append(filename)

                representative_image = saved_filenames[0] if saved_filenames else None
                new_member = FamilyMember(
                    user_id=user.id,
                    name=name,
                    relation=relation,
                    traits=traits,
                    image_filename=os.path.join(session['user'], name, representative_image) if representative_image else None
                )
                db.session.add(new_member)

        db.session.commit()
        try:
            dataset_path = os.path.join(app.config['UPLOAD_FOLDER'], session['user'])
            train_face_data(dataset_path)
            print("[✔] 얼굴 학습 데이터 재학습 완료")
        except Exception as e:
            print(f"[경고] 얼굴 학습 중 오류 발생: {e}")
        return redirect(url_for('edit_family'))

    family_members = FamilyMember.query.filter_by(user_id=user.id).all()
    return render_template('edit_family.html', family_members=family_members)



@app.route('/edit_family/<int:member_id>', methods=['POST'])
def update_family_member(member_id):
    if 'user' not in session:
        return redirect('/login')

    user = User.query.filter_by(userid=session['user']).first()
    member = FamilyMember.query.get(member_id)

    if not member or member.user_id != user.id:
        return "잘못된 접근입니다.", 403

    # 기존 이름 저장
    old_name = member.name

    # 새 입력값
    new_name = request.form.get('name')
    member.relation = request.form.get('relation')
    member.traits = request.form.get('traits')

    # 폴더 경로
    base_path = os.path.join(app.config['UPLOAD_FOLDER'], session['user'])
    old_folder = os.path.join(base_path, old_name)
    new_folder = os.path.join(base_path, new_name)

    # 🔁 이름이 바뀐 경우 폴더명도 변경
    if old_name != new_name:
        if os.path.exists(old_folder):
            os.rename(old_folder, new_folder)
        member.name = new_name  # DB에도 반영

    # 🔽 이미지 업데이트 로직은 동일 (기존 코드 유지)
    current_images = []
    if member.image_filename:
        folder_path = os.path.join(app.config['UPLOAD_FOLDER'], member.image_filename.rsplit('/', 1)[0])
        current_images = [os.path.basename(f) for f in glob.glob(os.path.join(folder_path, '*.jpg'))]

    to_delete = request.form.getlist('delete_images')
    for filename in to_delete:
        filepath = os.path.join(new_folder, filename)
        if os.path.exists(filepath):
            os.remove(filepath)
        if filename in current_images:
            current_images.remove(filename)

    new_images = request.files.getlist('new_images')
    for image in new_images:
        if image and image.filename:
            existing_files = glob.glob(os.path.join(new_folder, "*.jpg"))
            next_index = len(existing_files) + 1
            filename = f"{next_index}.jpg"
            image.save(os.path.join(new_folder, filename))
            current_images.append(filename)

    if current_images:
        member.image_filename = os.path.join(session['user'], new_name, current_images[0])
    else:
        member.image_filename = None

    db.session.commit()
    return redirect(url_for('edit_family'))

@app.route('/delete_all_images/<int:member_id>', methods=['POST'])
def delete_all_images(member_id):
    if 'user' not in session:
        return redirect('/login')
    
    user = User.query.filter_by(userid=session['user']).first()
    member = FamilyMember.query.get(member_id)

    if not member or member.user_id != user.id:
        return "잘못된 접근입니다.", 403

    # 이미지 폴더 경로
    image_folder = os.path.join(app.config['UPLOAD_FOLDER'], session['user'], member.name)
    
    if os.path.exists(image_folder):
        for file in os.listdir(image_folder):
            file_path = os.path.join(image_folder, file)
            if os.path.isfile(file_path):
                os.remove(file_path)

    # 대표 이미지 및 목록 초기화
    member.image_filename = None
    db.session.commit()

    return '', 204  # No Content

@app.route('/delete_family/<int:member_id>', methods=['GET'])
def delete_family_member(member_id):
    if 'user' not in session:
        return redirect('/login')

    user = User.query.filter_by(userid=session['user']).first()
    member = FamilyMember.query.get(member_id)

    if member and member.user_id == user.id:
        db.session.delete(member)
        db.session.commit()

    return redirect(url_for('edit_family'))

@app.route('/upload_slideshow', methods=['GET', 'POST'])
def upload_slideshow():
    if 'user' not in session:
        return redirect('/login')

    user_id = session['user']
    slideshow_folder = os.path.join(app.config['UPLOAD_FOLDER'], user_id, 'slideshow')

    os.makedirs(slideshow_folder, exist_ok=True)

    if request.method == 'POST':
        images = request.files.getlist('images')
        captions = request.form.getlist('captions[]')
        filenames = []

        for idx, image in enumerate(images[:40]):
            if image.filename:
                filename = f"{idx+1:02}.jpg"
                save_path = os.path.join(slideshow_folder, filename)
                image.save(save_path)
                filenames.append(filename)

        # 자막 저장
        captions_path = os.path.join(slideshow_folder, 'captions.json')
        with open(captions_path, 'w', encoding='utf-8') as f:
            json.dump(captions, f, ensure_ascii=False, indent=2)

        return redirect('/slideshow')

    return render_template('upload_slideshow.html')


@app.route("/slideshow")
def slideshow():
    if 'user' not in session:
        return redirect('/login')

    user_id = session['user']
    folder = os.path.join(app.config['UPLOAD_FOLDER'], user_id, 'slideshow')
    os.makedirs(folder, exist_ok=True)

    image_list = sorted([
        f for f in os.listdir(folder)
        if f.lower().endswith(('.jpg', '.jpeg', '.png'))
    ])

    # ✅ 자막 JSON 읽기
    captions_path = os.path.join(folder, 'captions.json')
    if os.path.exists(captions_path):
        with open(captions_path, 'r', encoding='utf-8') as f:
            captions = json.load(f)
    else:
        captions = [""] * len(image_list)

    return render_template(
        "slideshow_player.html",
        images_json=json.dumps(image_list),
        captions_json=json.dumps(captions, ensure_ascii=False),
        user_id=user_id
    )



@app.route('/reminder')
def show_reminder():
    if 'user' not in session:
        return redirect('/login')

    user_id = session['user']
    alarms = Alarm.query.filter_by(user_id=user_id).all()
    
    # 알람을 JSON으로 변환
    alarm_dicts = [{
        'label': a.label,
        'time': a.time,
        'days': a.days.split(',')
    } for a in alarms]

    return render_template('reminder.html',
                           alarms=alarms,
                           alarms_json=json.dumps(alarm_dicts, ensure_ascii=False))

@app.route('/add_alarm', methods=['POST'])
def add_alarm():
    if 'user' not in session:
        return redirect('/login')
    
    user_id = session['user']
    label = request.form.get('label')
    time = request.form.get('time')
    days = request.form.getlist('days')
    
    alarm = Alarm(user_id=user_id, label=label, time=time, days=",".join(days))
    db.session.add(alarm)
    db.session.commit()
    
    return redirect('/reminder')

@app.route('/get_alarms')
def get_alarms():
    if 'user' not in session:
        return jsonify([])
    user_id = session['user']
    alarms = Alarm.query.filter_by(user_id=user_id).all()
    result = [{
        'label': a.label,
        'time': a.time,
        'days': a.days.split(',')
    } for a in alarms]
    return jsonify(result)


@app.route('/logout', methods=['POST'])
def logout():
    session.clear()  # 로그인 상태 제거 (세션 초기화)
    return redirect(url_for('login'))  # 로그인 화면으로 이동

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4043, debug=True)

