import numpy as np
import cv2
import os
from PIL import Image, ImageDraw, ImageFont
from sklearn.metrics.pairwise import cosine_similarity

########## KNN CODE ############
def distance(v1, v2):
    return np.sqrt(((v1 - v2) ** 2).sum())

def knn(train, test, k=5):
    dist = []
    for i in range(train.shape[0]):
        ix = train[i, :-1]
        iy = train[i, -1]
        d = distance(test, ix)
        dist.append([d, iy])
    dk = sorted(dist, key=lambda x: x[0])[:k]
    labels = np.array(dk)[:, -1]
    output = np.unique(labels, return_counts=True)
    index = np.argmax(output[1])
    return output[0][index]

# ✅ 한글 텍스트 출력 함수
def draw_korean_text(img_bgr, text, position, font_path="/System/Library/Fonts/Supplemental/AppleGothic.ttf", font_size=24):
    img_pil = Image.fromarray(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    try:
        font = ImageFont.truetype(font_path, font_size)
    except:
        raise RuntimeError(f"폰트 파일을 찾을 수 없습니다: {font_path}")
    
    draw.text(position, text, font=font, fill=(255, 255, 0))  # 노란색 텍스트
    return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
################################

# face_detector.py 상단에 추가
def train_face_data(dataset_path):
    face_data = []
    labels = []
    names = {}
    class_id = 0

    for person_name in os.listdir(dataset_path):
        if person_name == "album":
            continue
        person_path = os.path.join(dataset_path, person_name)
        if not os.path.isdir(person_path):
            continue

        names[class_id] = person_name
        for img_name in os.listdir(person_path):
            if img_name.startswith('.') or not img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue
            img_path = os.path.join(person_path, img_name)
            img = cv2.imread(img_path)
            if img is None:
                continue

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            if len(faces) == 0:
                continue

            for face in faces[:1]:
                x, y, w, h = face
                offset = 10
                face_section = img[y-offset:y+h+offset, x-offset:x+w+offset]
                face_section = cv2.resize(face_section, (100, 100))
                face_data.append(face_section.flatten())
                labels.append(class_id)
        class_id += 1

    if not face_data:
        raise ValueError("학습할 얼굴 데이터가 없습니다.")

    face_dataset = np.array(face_data)
    face_labels = np.array(labels).reshape((-1, 1))
    trainset = np.concatenate((face_dataset, face_labels), axis=1)
    return trainset, names


# ✅ Load Haar Cascade
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_alt.xml")

# ✅ 이미지 학습 경로 (폴더 이름 = 사람 이름)
dataset_path = "/Users/dowon/Desktop/해커톤 프로젝트/static/uploads/kimdowon"
trainset, names = train_face_data(dataset_path)

############### 얼굴 인식 함수 ################

def recognize_faces_in_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("이미지를 불러올 수 없습니다. 경로를 확인하세요.")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    if len(faces) == 0:
        print(f"[!] 얼굴이 감지되지 않았습니다: {image_path}")
        return img

    best_face_info = None
    best_similarity = -1

    for face in faces:
        x, y, w, h = face
        offset = 10
        face_section = img[y-offset:y+h+offset, x-offset:x+w+offset]
        face_vector = cv2.resize(face_section, (100, 100)).flatten().reshape(1, -1)

        # ✅ KNN으로 k개 후보 찾기
        dist = []
        for i in range(trainset.shape[0]):
            ix = trainset[i, :-1]
            iy = trainset[i, -1]
            d = distance(face_vector.flatten(), ix)
            dist.append((d, ix, int(iy)))
        dist = sorted(dist, key=lambda x: x[0])[:5]  # k=5

        # ✅ KNN 후보 중 코사인 유사도 최고인 사람
        max_sim = -1
        best_id = None
        for _, candidate_vector, candidate_id in dist:
            sim = cosine_similarity(face_vector, candidate_vector.reshape(1, -1))[0][0]
            if sim > max_sim:
                max_sim = sim
                best_id = candidate_id

        # ✅ 전체 얼굴 중 가장 유사한 사람만 저장
        if max_sim > best_similarity:
            best_similarity = max_sim
            best_face_info = {
                "face": face,
                "name": names[best_id],
                "similarity": max_sim
            }

    # ✅ 가장 유사한 얼굴 하나만 시각화
    # 얼굴 인식 결과 저장 리스트
    recognized_faces = []

    for face in faces:
        x, y, w, h = face
        offset = 10
        face_section = img[y-offset:y+h+offset, x-offset:x+w+offset]
        face_vector = cv2.resize(face_section, (100, 100)).flatten().reshape(1, -1)

        dist = []
        for i in range(trainset.shape[0]):
            ix = trainset[i, :-1]
            iy = trainset[i, -1]
            d = distance(face_vector.flatten(), ix)
            dist.append((d, ix, int(iy)))

        dist = sorted(dist, key=lambda x: x[0])[:5]

        max_sim = -1
        best_id = None
        for _, candidate_vector, candidate_id in dist:
            sim = cosine_similarity(face_vector, candidate_vector.reshape(1, -1))[0][0]
            if sim > max_sim:
                max_sim = sim
                best_id = candidate_id

        if any(result["name"] == names[best_id] for result in recognized_faces):
            continue  # 이미 인식된 사람은 다시 표시하지 않음

        recognized_faces.append({
            "face": face,
            "name": names[best_id],
            "similarity": max_sim
        })

    # 모든 인식된 얼굴 시각화
    for result in recognized_faces:
        x, y, w, h = result["face"]
        name = result["name"]
        sim = result["similarity"]
        label = f"{name} ({sim:.2f})"

        img = draw_korean_text(img, label, (x, y - 30), font_size=40)
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 6)

    return img

############### 실행 예시 ################
if __name__ == "__main__":
    test_image_path = "/Users/dowon/Desktop/해커톤 프로젝트/static/uploads/kimdowon/album/KakaoTalk_Photo_2025-05-11-03-36-23.jpeg"
    result_img = recognize_faces_in_image(test_image_path)

    if result_img is not None:
        # ✅ 저장 폴더 경로
        album_path = "/Users/dowon/Desktop/해커톤 프로젝트/static/uploads/kimdowon/album"
        os.makedirs(album_path, exist_ok=True)

        # ✅ 숫자 파일명 생성 (이미 존재하는 숫자 기반)
        existing_files = [f for f in os.listdir(album_path) if f.endswith(('.jpg', '.jpeg', '.png'))]
        numbers = [int(os.path.splitext(f)[0]) for f in existing_files if os.path.splitext(f)[0].isdigit()]
        next_index = max(numbers) + 1 if numbers else 1
        save_path = os.path.join(album_path, f"{next_index}.jpg")

        # ✅ 저장
        cv2.imwrite(save_path, result_img)
        print(f"[✔] 결과 이미지 저장 완료: {save_path}")

        # ✅ 화면 표시
        cv2.imshow("Face Recognition Result", result_img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
